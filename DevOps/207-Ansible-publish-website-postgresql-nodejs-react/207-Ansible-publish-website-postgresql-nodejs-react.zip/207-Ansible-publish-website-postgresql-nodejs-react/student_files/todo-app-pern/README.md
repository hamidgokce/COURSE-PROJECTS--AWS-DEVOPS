# Clarus Todos App Using PERN

## PERN : PostgreSQL - Express - ReactJS - NodeJS

### server .env file content:

SERVER_PORT=  
DB_USER=  
DB_PASSWORD=  
DB_NAME=  
DB_HOST=  
DB_PORT=
